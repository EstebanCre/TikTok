#!/bin/bash
# install_free_version.sh
# Script d'installation automatique pour VPS

echo "========================================"
echo "🚀 Installation TikTok Automation Free"
echo "========================================"
echo ""

# Couleurs
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Fonction pour afficher les étapes
step() {
    echo -e "${GREEN}[✓]${NC} $1"
}

error() {
    echo -e "${RED}[✗]${NC} $1"
}

warning() {
    echo -e "${YELLOW}[!]${NC} $1"
}

# Vérifier si on est root
if [ "$EUID" -ne 0 ]; then 
    warning "Ce script doit être exécuté en root"
    echo "Utilisez: sudo bash install_free_version.sh"
    exit 1
fi

# 1. Mise à jour du système
step "Mise à jour du système..."
apt update && apt upgrade -y

# 2. Installation de Python 3
step "Installation de Python 3..."
apt install -y python3 python3-pip python3-venv

# 3. Installation de FFmpeg
step "Installation de FFmpeg..."
apt install -y ffmpeg

# 4. Installation de Git
step "Installation de Git..."
apt install -y git

# 5. Installation de Nginx (optionnel, pour production)
warning "Installation de Nginx (optionnel)..."
read -p "Installer Nginx pour servir l'application? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    apt install -y nginx
    step "Nginx installé"
fi

# 6. Créer le dossier de l'application
step "Création du dossier de l'application..."
APP_DIR="/opt/tiktok-automation"
mkdir -p $APP_DIR
cd $APP_DIR

# 7. Télécharger les fichiers
step "Téléchargement des fichiers de l'application..."

# Si vous avez un repo Git
# git clone https://github.com/votre-repo/tiktok-automation-free.git .

# Sinon, créer la structure manuellement
mkdir -p generated_videos temp

# 8. Créer l'environnement virtuel Python
step "Création de l'environnement virtuel Python..."
python3 -m venv venv
source venv/bin/activate

# 9. Installer les dépendances Python
step "Installation des dépendances Python..."
cat > requirements_free.txt << 'EOF'
Flask==3.0.0
flask-cors==4.0.0
groq==0.4.1
edge-tts==6.1.9
Pillow==10.1.0
requests==2.31.0
python-dotenv==1.0.0
EOF

pip install -r requirements_free.txt

# 10. Créer le fichier .env
step "Configuration des variables d'environnement..."
cat > .env << 'EOF'
# Groq API (gratuit sur groq.com)
GROQ_API_KEY=votre_cle_groq

# Pexels API (gratuit sur pexels.com/api)
PEXELS_API_KEY=votre_cle_pexels

# TikTok API (gratuit sur developers.tiktok.com)
TIKTOK_CLIENT_KEY=votre_cle_tiktok
TIKTOK_CLIENT_SECRET=votre_secret_tiktok
EOF

warning "IMPORTANT: Éditez le fichier .env avec vos clés API:"
echo "nano $APP_DIR/.env"
echo ""
echo "Obtenez vos clés gratuites sur:"
echo "  • Groq: https://console.groq.com"
echo "  • Pexels: https://www.pexels.com/api/new/"
echo "  • TikTok: https://developers.tiktok.com/"
echo ""

# 11. Créer un service systemd
step "Création du service systemd..."
cat > /etc/systemd/system/tiktok-automation.service << EOF
[Unit]
Description=TikTok Automation Free
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$APP_DIR
Environment="PATH=$APP_DIR/venv/bin"
ExecStart=$APP_DIR/venv/bin/python backend_free_version.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# 12. Configuration du firewall
step "Configuration du firewall..."
ufw allow 22    # SSH
ufw allow 5000  # Application
ufw allow 80    # HTTP (si Nginx)
ufw allow 443   # HTTPS (si Nginx)
ufw --force enable

# 13. Configuration Nginx (si installé)
if command -v nginx &> /dev/null; then
    step "Configuration de Nginx..."
    
    cat > /etc/nginx/sites-available/tiktok-automation << 'EOF'
server {
    listen 80;
    server_name _;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Support pour les fichiers volumineux (vidéos)
        client_max_body_size 100M;
    }
}
EOF

    ln -sf /etc/nginx/sites-available/tiktok-automation /etc/nginx/sites-enabled/
    nginx -t && systemctl restart nginx
    step "Nginx configuré"
fi

# 14. Activer et démarrer le service
step "Activation du service..."
systemctl daemon-reload
systemctl enable tiktok-automation.service

echo ""
echo "========================================"
echo "✅ Installation terminée!"
echo "========================================"
echo ""
echo "📝 Prochaines étapes:"
echo ""
echo "1. Éditez vos clés API:"
echo "   nano $APP_DIR/.env"
echo ""
echo "2. Démarrez l'application:"
echo "   systemctl start tiktok-automation"
echo ""
echo "3. Vérifiez le statut:"
echo "   systemctl status tiktok-automation"
echo ""
echo "4. Voir les logs:"
echo "   journalctl -u tiktok-automation -f"
echo ""

if command -v nginx &> /dev/null; then
    echo "5. Accédez à votre application:"
    echo "   http://VOTRE_IP_VPS"
else
    echo "5. Accédez à votre application:"
    echo "   http://VOTRE_IP_VPS:5000"
fi

echo ""
echo "========================================"
echo "🎬 Coût total: 0€/mois"
echo "========================================"
echo ""

# Afficher les infos système
echo "📊 Informations système:"
echo "   • CPU: $(nproc) cores"
echo "   • RAM: $(free -h | awk '/^Mem:/ {print $2}')"
echo "   • Disque: $(df -h / | awk 'NR==2 {print $4}') disponible"
echo "   • Python: $(python3 --version)"
echo "   • FFmpeg: $(ffmpeg -version | head -n1)"
echo ""

warning "N'oubliez pas de configurer vos clés API dans .env !"
