# 🚀 Guide de Démarrage Rapide - Version Gratuite

## Installation en 5 minutes sur votre VPS

### Étape 1: Connexion à votre VPS

```bash
ssh root@votre_ip_vps
```

### Étape 2: Installation automatique

```bash
# Télécharger le script d'installation
wget https://raw.githubusercontent.com/votre-repo/install_free_version.sh

# Rendre le script exécutable
chmod +x install_free_version.sh

# Lancer l'installation
sudo bash install_free_version.sh
```

### Étape 3: Obtenir les clés API (GRATUITES)

#### 3.1 Groq (Scripts IA - Gratuit)
1. Aller sur https://console.groq.com
2. Créer un compte gratuit
3. Générer une clé API
4. Copier la clé

#### 3.2 Pexels (Images - Gratuit)
1. Aller sur https://www.pexels.com/api/new/
2. Créer un compte gratuit
3. Générer une clé API
4. Copier la clé

#### 3.3 TikTok (Publication - Gratuit)
1. Aller sur https://developers.tiktok.com/
2. Créer une application
3. Obtenir Client Key et Client Secret
4. Copier les clés

### Étape 4: Configuration

```bash
# Éditer le fichier .env
nano /opt/tiktok-automation/.env

# Remplir avec vos clés:
GROQ_API_KEY=gsk_xxxxxxxxxxxxx
PEXELS_API_KEY=xxxxxxxxxxxxx
TIKTOK_CLIENT_KEY=xxxxxxxxxxxxx
TIKTOK_CLIENT_SECRET=xxxxxxxxxxxxx

# Sauvegarder: Ctrl+X puis Y puis Enter
```

### Étape 5: Démarrer l'application

```bash
# Démarrer le service
systemctl start tiktok-automation

# Vérifier que ça tourne
systemctl status tiktok-automation

# Voir les logs en temps réel
journalctl -u tiktok-automation -f
```

### Étape 6: Accéder à l'interface

Ouvrir votre navigateur:
```
http://VOTRE_IP_VPS:5000
```

Ou si vous avez installé Nginx:
```
http://VOTRE_IP_VPS
```

---

## 🎬 Utilisation

### Générer votre première vidéo

1. Aller sur l'interface web
2. Entrer un sujet (ex: "5 astuces pour bien dormir")
3. Choisir une niche (ex: "Santé")
4. Cliquer sur "Générer"
5. Attendre 2-5 minutes
6. Télécharger et valider!

### Exemple de génération

```bash
# Via l'API directement
curl -X POST http://localhost:5000/api/generate \
  -H "Content-Type: application/json" \
  -d '{
    "topic": "5 astuces productivité",
    "niche": "education",
    "duration": 30
  }'
```

---

## 📊 Limites Gratuites

| Service | Limite Gratuite | Suffisant pour |
|---------|----------------|----------------|
| Groq | 30 req/min | ~1000 vidéos/jour |
| Pexels | 200 req/heure | ~5000 vidéos/jour |
| Edge TTS | Illimité | ∞ |
| FFmpeg | Illimité | ∞ |
| TikTok API | ~100 posts/jour | 100 vidéos/jour |

**Capacité totale**: ~100 vidéos/jour GRATUITEMENT!

---

## 🔧 Commandes Utiles

### Gérer le service

```bash
# Démarrer
systemctl start tiktok-automation

# Arrêter
systemctl stop tiktok-automation

# Redémarrer
systemctl restart tiktok-automation

# Voir le statut
systemctl status tiktok-automation

# Activer au démarrage
systemctl enable tiktok-automation
```

### Logs et débogage

```bash
# Voir les logs
journalctl -u tiktok-automation

# Logs en temps réel
journalctl -u tiktok-automation -f

# Dernières 100 lignes
journalctl -u tiktok-automation -n 100
```

### Maintenance

```bash
# Nettoyer les fichiers temporaires
rm -rf /opt/tiktok-automation/temp/*

# Voir l'espace disque utilisé
du -sh /opt/tiktok-automation/generated_videos/

# Sauvegarder la base de données
cp /opt/tiktok-automation/tiktok_automation.db ~/backup_$(date +%F).db
```

---

## 🎯 Workflow Recommandé

### Pour débuter (Jours 1-7)
1. Générer 1-3 vidéos/jour
2. Tester différentes niches
3. Observer les performances

### Phase de test (Jours 8-30)
1. Générer 5-10 vidéos/jour
2. Identifier ce qui marche
3. Affiner les templates

### Phase d'optimisation (Mois 2+)
1. Générer 20-50 vidéos/jour
2. Automatiser la publication
3. Analyser les métriques

---

## 💡 Astuces pour Optimiser

### 1. Créer des templates de sujets

```bash
# Créer un fichier topics.txt
cat > /opt/tiktok-automation/topics.txt << EOF
5 astuces pour [thème]
Ce que personne ne vous dit sur [thème]
La vérité sur [thème]
Comment j'ai [résultat] en [temps]
[Nombre] erreurs à éviter avec [thème]
EOF
```

### 2. Batch generation (générer en masse)

```python
# script_batch.py
topics = [
    "productivité",
    "sommeil",
    "nutrition",
    "sport",
    "argent"
]

for topic in topics:
    # Générer chaque vidéo
    pass
```

### 3. Optimiser les images

```bash
# Télécharger une fois, réutiliser souvent
mkdir -p /opt/tiktok-automation/image_cache
```

---

## 🔒 Sécurité

### Configurer le firewall

```bash
# Bloquer tout sauf SSH et l'app
ufw default deny incoming
ufw default allow outgoing
ufw allow 22
ufw allow 5000
ufw enable
```

### Créer un utilisateur non-root

```bash
# Créer un utilisateur
adduser tiktokapp
usermod -aG sudo tiktokapp

# Changer le propriétaire des fichiers
chown -R tiktokapp:tiktokapp /opt/tiktok-automation
```

### Sauvegardes automatiques

```bash
# Créer un cron job
crontab -e

# Ajouter cette ligne (backup quotidien)
0 2 * * * cp /opt/tiktok-automation/tiktok_automation.db ~/backups/backup_$(date +\%F).db
```

---

## 📈 Monitoring

### Vérifier la santé de l'app

```bash
# Health check
curl http://localhost:5000/health

# Réponse attendue:
# {
#   "status": "ok",
#   "services": {
#     "script_generation": "Groq",
#     "voice": "Edge TTS",
#     "images": "Pexels",
#     "video": "FFmpeg"
#   }
# }
```

### Surveiller les ressources

```bash
# CPU et RAM
htop

# Espace disque
df -h

# Processus Python
ps aux | grep python
```

---

## ⚠️ Dépannage

### L'app ne démarre pas

```bash
# Vérifier les logs
journalctl -u tiktok-automation -n 50

# Vérifier les permissions
ls -la /opt/tiktok-automation

# Tester manuellement
cd /opt/tiktok-automation
source venv/bin/activate
python backend_free_version.py
```

### Erreurs de génération

```bash
# Vérifier les clés API
cat /opt/tiktok-automation/.env

# Tester FFmpeg
ffmpeg -version

# Tester Edge TTS
edge-tts --list-voices | grep fr-FR
```

### Problèmes de connexion

```bash
# Vérifier le port
netstat -tulpn | grep 5000

# Vérifier le firewall
ufw status

# Tester localement
curl http://localhost:5000
```

---

## 🚀 Passage en Production

### Utiliser Nginx (recommandé)

```bash
# Déjà configuré si installé avec le script
systemctl status nginx

# Tester la config
nginx -t

# Redémarrer
systemctl restart nginx
```

### Ajouter HTTPS (Let's Encrypt)

```bash
# Installer certbot
apt install certbot python3-certbot-nginx

# Obtenir un certificat (remplacer par votre domaine)
certbot --nginx -d votredomaine.com

# Renouvellement automatique
certbot renew --dry-run
```

### Augmenter les performances

```bash
# Éditer la config
nano /etc/systemd/system/tiktok-automation.service

# Ajouter:
Environment="PYTHONUNBUFFERED=1"
Environment="WORKERS=4"

# Recharger
systemctl daemon-reload
systemctl restart tiktok-automation
```

---

## 📞 Support

### Vérifier la version

```bash
curl http://localhost:5000/health
```

### Logs détaillés

```bash
# Activer le mode debug
# Dans backend_free_version.py, ligne finale:
# app.run(debug=True)
```

### Communauté

- GitHub Issues: [lien]
- Discord: [lien]
- Forum: [lien]

---

## ✅ Checklist de Démarrage

- [ ] VPS configuré et accessible
- [ ] Script d'installation exécuté
- [ ] Clés API Groq obtenues
- [ ] Clés API Pexels obtenues
- [ ] Clés API TikTok obtenues
- [ ] Fichier .env configuré
- [ ] Service démarré et actif
- [ ] Interface web accessible
- [ ] Première vidéo générée avec succès
- [ ] Vidéo validée et prête
- [ ] Publication TikTok testée

---

## 🎉 Vous êtes prêt!

Votre système est maintenant opérationnel et peut générer du contenu TikTok **gratuitement**!

**Prochaine étape**: Générer vos 10 premières vidéos et analyser les résultats!

**Coût total**: 0€/mois (hors VPS que vous avez déjà)

---

Besoin d'aide? Consultez les logs et la documentation complète dans FREE_VERSION_GUIDE.md
