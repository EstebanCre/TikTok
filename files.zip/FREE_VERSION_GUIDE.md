# Version Gratuite - Application TikTok Automation

## 🎯 Architecture Simplifiée (Budget: 0-20€/mois)

### Stack 100% Gratuite

#### Backend Minimaliste
- **Flask** (Python) - Plus léger que FastAPI, parfait pour VPS
- **SQLite** - Base de données fichier (pas besoin de PostgreSQL)
- Pas de Redis/Celery - traitement synchrone simplifié

#### Génération de Contenu GRATUITE

##### 1. Scripts (IA)
**Option A: Claude via API Anthropic** (5$ gratuits à l'inscription)
- ~200 générations de scripts gratuites au démarrage
- Ensuite ~0.50€ pour 100 scripts

**Option B: Llama 3 (100% gratuit via Groq)**
```python
# API Groq - Gratuit et rapide
from groq import Groq
client = Groq(api_key="gratuit")
response = client.chat.completions.create(
    model="llama-3.1-70b-versatile",  # GRATUIT
    messages=[{"role": "user", "content": prompt}]
)
```

**Option C: Ollama (local, 100% gratuit)**
```bash
# Installer Ollama sur votre VPS
curl -fsSL https://ollama.com/install.sh | sh
ollama run llama3.1  # Gratuit, tourne localement
```

##### 2. Voix-off (TTS)

**Option A: Piper TTS (100% gratuit, local)**
```bash
# TTS local de haute qualité
pip install piper-tts
# Voix française disponible gratuitement
```

**Option B: gTTS (Google TTS gratuit)**
```python
from gtts import gTTS
tts = gTTS("Votre texte", lang='fr')
tts.save("voiceover.mp3")  # GRATUIT, qualité correcte
```

**Option C: Edge TTS (Microsoft, gratuit)**
```bash
pip install edge-tts
edge-tts --text "Votre texte" --write-media voiceover.mp3
# Qualité excellente, 100% gratuit
```

##### 3. Images/Visuels

**Option A: Pexels/Pixabay API (gratuit)**
```python
import requests
# API Pexels - 200 requêtes/heure GRATUIT
response = requests.get(
    "https://api.pexels.com/v1/search",
    headers={"Authorization": "VOTRE_CLE_GRATUITE"},
    params={"query": "productivity", "per_page": 5}
)
```

**Option B: Unsplash API (gratuit)**
- 50 requêtes/heure gratuit
- Images haute qualité

**Option C: Stable Diffusion (local, gratuit)**
```bash
# Générer des images IA localement
pip install diffusers torch
# Utilise la VRAM de votre GPU (ou CPU)
```

##### 4. Assemblage Vidéo

**FFmpeg (100% gratuit, open source)**
- Déjà installé sur la plupart des VPS
- Aucun coût

#### Stockage

**Option A: Stockage local sur VPS**
- Inclus dans votre VPS
- 0€ supplémentaire

**Option B: Cloudflare R2** (10 GB gratuit/mois)
- Alternative à S3
- Parfait pour débuter

### 📋 Stack Technique Gratuite Recommandée

```yaml
Backend: Flask (Python)
Base de données: SQLite
IA Texte: Groq (Llama 3) - GRATUIT
TTS: Edge TTS - GRATUIT  
Images: Pexels API - GRATUIT
Vidéo: FFmpeg - GRATUIT
Stockage: VPS local - GRATUIT
Frontend: HTML/CSS/JS vanilla - GRATUIT
```

### 💰 Comparaison des Coûts

| Service | Version Payante | Version Gratuite |
|---------|----------------|------------------|
| IA Scripts | Claude $50-200/mois | Groq: 0€ |
| TTS Voix | ElevenLabs $22-330/mois | Edge TTS: 0€ |
| Images | Shutterstock $29/mois | Pexels: 0€ |
| Vidéo Gen | Runway $12-76/mois | FFmpeg: 0€ |
| Stockage | S3 $5-30/mois | VPS: 0€ |
| **TOTAL** | **$118-665/mois** | **0-5€/mois** |

### 🚀 Installation sur votre VPS

#### 1. Prérequis VPS
```bash
# Minimum recommandé:
# - 2 GB RAM
# - 20 GB disque
# - Ubuntu 20.04+

# Mise à jour
sudo apt update && sudo apt upgrade -y

# Python et pip
sudo apt install python3 python3-pip python3-venv -y

# FFmpeg
sudo apt install ffmpeg -y

# Git
sudo apt install git -y
```

#### 2. Installation du projet
```bash
# Créer le dossier
mkdir ~/tiktok-automation
cd ~/tiktok-automation

# Environnement virtuel Python
python3 -m venv venv
source venv/bin/activate

# Installer les dépendances
pip install flask groq edge-tts pexels-py moviepy pillow
```

#### 3. Configuration TikTok API
```bash
# L'API TikTok est GRATUITE
# Inscription sur: https://developers.tiktok.com/
# Pas de frais, juste les limites de rate
```

### 📝 Code Backend Simplifié (Flask)

Voir fichier: `backend_free_version.py`

### 🎨 Frontend Simple (HTML/JS)

Voir fichier: `frontend_simple.html`

### ⚙️ Configuration

```bash
# .env
GROQ_API_KEY=gratuit_sur_groq_com
PEXELS_API_KEY=gratuit_sur_pexels_com
TIKTOK_CLIENT_KEY=votre_cle
TIKTOK_CLIENT_SECRET=votre_secret
```

### 🔄 Workflow Simplifié

```
1. Utilisateur saisit une idée/thème
   ↓
2. Groq génère le script (gratuit)
   ↓
3. Edge TTS crée la voix (gratuit)
   ↓
4. Pexels fournit les images (gratuit)
   ↓
5. FFmpeg assemble la vidéo (gratuit)
   ↓
6. Interface de validation
   ↓
7. Publication sur TikTok (gratuit)
```

### 📊 Limites de la Version Gratuite

| Aspect | Limite |
|--------|--------|
| Scripts/jour | ~100 (Groq) |
| Voix-off/jour | Illimité (Edge TTS) |
| Images/jour | ~5000 (Pexels) |
| Vidéos/mois | Limité par TikTok API (~100) |
| Stockage | Dépend de votre VPS |

### 🎯 Plan de Migration

**Phase 1: Gratuit (Mois 1-2)**
- Tester le concept
- Générer 50-100 vidéos
- Valider l'audience

**Phase 2: Hybrid (Mois 3-4)**
- Groq → Claude pour meilleurs scripts (5-20€)
- Edge TTS → ElevenLabs pour 1 voix custom (22€)
- Coût: ~30€/mois

**Phase 3: Premium (Mois 5+)**
- Full stack payant si rentable
- Coût: ~150€/mois

### 🔧 Optimisations VPS

```bash
# Installer Nginx comme reverse proxy
sudo apt install nginx

# Configuration Nginx pour servir l'app
# Fichier: /etc/nginx/sites-available/tiktok-app
```

### 💡 Astuces pour Réduire les Coûts

1. **Batch processing**: Générer plusieurs vidéos d'un coup
2. **Caching**: Sauvegarder les images populaires
3. **Templates**: Réutiliser des structures de scripts
4. **Compression**: Optimiser les vidéos avec FFmpeg
5. **Scheduling**: Générer pendant les heures creuses

### 🎬 Qualité Attendue (Version Gratuite)

**Scripts**: ⭐⭐⭐⭐ (Llama 3 très bon)
**Voix**: ⭐⭐⭐ (Edge TTS acceptable, pas professionnel)
**Images**: ⭐⭐⭐⭐ (Pexels excellentes)
**Vidéo**: ⭐⭐⭐⭐ (FFmpeg = qualité pro)

**Résultat**: Suffisant pour tester et valider le concept !

### 📈 Métriques de Succès pour Upgrade

Passer à la version payante si:
- ✅ >1000 vues/vidéo en moyenne
- ✅ >50 vidéos publiées avec succès
- ✅ Taux d'engagement >3%
- ✅ Début de monétisation

### 🆚 Différences Clés

| Fonctionnalité | Version Gratuite | Version Payante |
|----------------|------------------|-----------------|
| Qualité scripts | 7/10 | 9/10 |
| Qualité voix | 6/10 | 9/10 |
| Vitesse génération | 2-5 min | 1-2 min |
| Support | Communauté | Prioritaire |
| Scalabilité | 10 vidéos/jour | 100+ vidéos/jour |

### 📚 Ressources Gratuites

- **Groq API**: https://groq.com (gratuit)
- **Edge TTS**: https://github.com/rany2/edge-tts
- **Pexels API**: https://www.pexels.com/api/
- **Unsplash API**: https://unsplash.com/developers
- **TikTok API**: https://developers.tiktok.com/
- **FFmpeg Guide**: https://ffmpeg.org/documentation.html

### 🎓 Tutoriel Rapide

```bash
# 1. Installer sur votre VPS
git clone <votre-repo>
cd tiktok-automation-free

# 2. Setup
python3 -m venv venv
source venv/bin/activate
pip install -r requirements_free.txt

# 3. Configuration
cp .env.example .env
nano .env  # Ajouter vos clés gratuites

# 4. Lancer
python backend_free_version.py

# 5. Accéder
# http://votre-vps-ip:5000
```

### ⚠️ Points d'Attention

1. **Groq Rate Limits**: 
   - 30 requêtes/minute (largement suffisant)
   - 14,400 requêtes/jour gratuit

2. **Edge TTS**:
   - Qualité Microsoft, pas de limite
   - Parfois voix "robotique" sur longs textes

3. **Pexels**:
   - Attribution requise (mention "Photo by X on Pexels")
   - Vérifier les droits pour usage commercial

4. **TikTok API**:
   - Rate limits stricts
   - Max ~100 publications/jour par compte

### 🔒 Sécurité VPS

```bash
# Firewall basique
sudo ufw allow 22    # SSH
sudo ufw allow 80    # HTTP
sudo ufw allow 443   # HTTPS
sudo ufw enable

# Process manager
pip install supervisor  # Ou pm2 pour Node.js
```

---

**Conclusion**: Avec cette version gratuite, vous pouvez générer 50-100 vidéos TikTok par mois sans frais, directement depuis votre VPS existant. Parfait pour tester le concept avant d'investir !
