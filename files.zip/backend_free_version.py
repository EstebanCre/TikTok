# backend_free_version.py
"""
Version gratuite de l'application TikTok Automation
Stack: Flask + SQLite + Groq + Edge TTS + Pexels + FFmpeg
Coût: 0€/mois
"""

from flask import Flask, request, jsonify, send_file, render_template_string
from flask_cors import CORS
import sqlite3
import os
import asyncio
from pathlib import Path
from datetime import datetime
import json
import uuid

# Import des services gratuits
from groq import Groq
import edge_tts
import subprocess
import requests
from PIL import Image
import io

app = Flask(__name__)
CORS(app)

# Configuration
BASE_DIR = Path(__file__).parent
DB_PATH = BASE_DIR / "tiktok_automation.db"
VIDEOS_DIR = BASE_DIR / "generated_videos"
TEMP_DIR = BASE_DIR / "temp"

VIDEOS_DIR.mkdir(exist_ok=True)
TEMP_DIR.mkdir(exist_ok=True)

# Clés API (gratuites)
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
PEXELS_API_KEY = os.getenv("PEXELS_API_KEY", "")
TIKTOK_CLIENT_KEY = os.getenv("TIKTOK_CLIENT_KEY", "")
TIKTOK_CLIENT_SECRET = os.getenv("TIKTOK_CLIENT_SECRET", "")

# ==================== BASE DE DONNÉES ====================

def init_db():
    """Initialise la base SQLite"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS videos (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            script TEXT NOT NULL,
            status TEXT DEFAULT 'generating',
            video_path TEXT,
            thumbnail_path TEXT,
            hashtags TEXT,
            description TEXT,
            tiktok_video_id TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            published_at TIMESTAMP,
            views INTEGER DEFAULT 0,
            likes INTEGER DEFAULT 0,
            comments INTEGER DEFAULT 0
        )
    """)
    
    conn.commit()
    conn.close()

# ==================== SERVICES GRATUITS ====================

class FreeScriptGenerator:
    """Génération de scripts avec Groq (Llama 3 - Gratuit)"""
    
    def __init__(self):
        self.client = Groq(api_key=GROQ_API_KEY)
    
    def generate_script(self, topic: str, niche: str, duration: int = 30) -> dict:
        """Génère un script TikTok"""
        
        prompt = f"""Tu es un expert en création de contenu TikTok viral.

Crée un script pour une vidéo TikTok de {duration} secondes sur le thème: "{topic}"
Niche: {niche}

Le script doit:
1. Avoir un HOOK captivant dans les 3 premières secondes
2. Être concis et rythmé
3. Inclure 3-5 points clés
4. Se terminer par un call-to-action
5. Être adapté pour une voix-off

Format de réponse (JSON):
{{
    "hook": "phrase d'accroche puissante",
    "content": "contenu principal divisé en points",
    "cta": "appel à l'action",
    "suggested_hashtags": ["#tag1", "#tag2", "#tag3"],
    "visual_suggestions": ["suggestion visuelle 1", "suggestion 2"]
}}

Réponds UNIQUEMENT avec le JSON, sans texte avant ou après."""

        try:
            response = self.client.chat.completions.create(
                model="llama-3.1-70b-versatile",  # Gratuit
                messages=[
                    {"role": "system", "content": "Tu es un expert en contenu TikTok. Réponds toujours en JSON valide."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=1000
            )
            
            content = response.choices[0].message.content
            # Nettoyer la réponse (enlever markdown si présent)
            content = content.replace("```json", "").replace("```", "").strip()
            
            return json.loads(content)
            
        except Exception as e:
            # Fallback en cas d'erreur
            return {
                "hook": f"🔥 Découvrez {topic} !",
                "content": f"Voici ce que vous devez savoir sur {topic}. Point 1: Important. Point 2: Très important. Point 3: Crucial.",
                "cta": "Likez et suivez pour plus !",
                "suggested_hashtags": ["#tiktok", "#viral", "#trending"],
                "visual_suggestions": [topic, "trendy", "modern"]
            }

class FreeVoiceGenerator:
    """Génération de voix avec Edge TTS (Microsoft - Gratuit)"""
    
    FRENCH_VOICES = {
        "female_claire": "fr-FR-DeniseNeural",
        "female_brigitte": "fr-FR-BrigitteNeural", 
        "male_henri": "fr-FR-HenriNeural",
        "male_alain": "fr-FR-AlainNeural"
    }
    
    async def generate_voiceover(
        self,
        text: str,
        output_path: str,
        voice: str = "female_claire",
        rate: str = "+10%",  # Vitesse (plus rapide = plus dynamique)
        pitch: str = "+0Hz"
    ) -> str:
        """Génère une voix-off gratuite avec Edge TTS"""
        
        voice_name = self.FRENCH_VOICES.get(voice, self.FRENCH_VOICES["female_claire"])
        
        communicate = edge_tts.Communicate(
            text=text,
            voice=voice_name,
            rate=rate,
            pitch=pitch
        )
        
        await communicate.save(output_path)
        return output_path

class FreeImageProvider:
    """Récupère des images gratuites depuis Pexels"""
    
    def __init__(self):
        self.api_key = PEXELS_API_KEY
        self.base_url = "https://api.pexels.com/v1"
    
    def search_images(self, query: str, count: int = 5) -> list:
        """Recherche des images gratuites"""
        
        headers = {"Authorization": self.api_key}
        params = {
            "query": query,
            "per_page": count,
            "orientation": "portrait"  # Format 9:16 pour TikTok
        }
        
        try:
            response = requests.get(
                f"{self.base_url}/search",
                headers=headers,
                params=params
            )
            response.raise_for_status()
            
            data = response.json()
            images = []
            
            for photo in data.get("photos", []):
                images.append({
                    "url": photo["src"]["large"],
                    "photographer": photo["photographer"],
                    "download_url": photo["src"]["original"]
                })
            
            return images
            
        except Exception as e:
            print(f"Pexels error: {e}")
            return []
    
    def download_image(self, url: str, output_path: str):
        """Télécharge une image"""
        response = requests.get(url)
        with open(output_path, 'wb') as f:
            f.write(response.content)

class FreeVideoAssembler:
    """Assemblage vidéo avec FFmpeg (gratuit)"""
    
    def __init__(self):
        self.temp_dir = TEMP_DIR
    
    def create_slideshow_video(
        self,
        images: list,
        audio_path: str,
        output_path: str,
        duration_per_image: float = 3.0
    ) -> str:
        """Crée une vidéo slideshow simple"""
        
        # 1. Créer un fichier concat pour FFmpeg
        concat_file = self.temp_dir / "concat.txt"
        with open(concat_file, 'w') as f:
            for img in images:
                f.write(f"file '{img}'\n")
                f.write(f"duration {duration_per_image}\n")
            # Répéter la dernière image
            f.write(f"file '{images[-1]}'\n")
        
        # 2. Assembler avec FFmpeg
        cmd = [
            "ffmpeg", "-y",
            "-f", "concat",
            "-safe", "0",
            "-i", str(concat_file),
            "-i", audio_path,
            "-vf", "scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2,setsar=1",
            "-c:v", "libx264",
            "-preset", "medium",
            "-crf", "23",
            "-c:a", "aac",
            "-b:a", "192k",
            "-shortest",
            "-r", "30",
            "-pix_fmt", "yuv420p",
            str(output_path)
        ]
        
        try:
            subprocess.run(cmd, check=True, capture_output=True)
            return str(output_path)
        except subprocess.CalledProcessError as e:
            raise Exception(f"FFmpeg error: {e.stderr.decode()}")
    
    def add_text_overlay(
        self,
        video_path: str,
        text: str,
        output_path: str,
        position: str = "bottom"
    ) -> str:
        """Ajoute du texte sur la vidéo"""
        
        # Position du texte
        if position == "top":
            y_pos = "50"
        elif position == "center":
            y_pos = "(h-text_h)/2"
        else:  # bottom
            y_pos = "h-text_h-50"
        
        # Commande FFmpeg pour overlay de texte
        cmd = [
            "ffmpeg", "-y",
            "-i", video_path,
            "-vf",
            f"drawtext=text='{text}':fontsize=48:fontcolor=white:x=(w-text_w)/2:y={y_pos}:box=1:boxcolor=black@0.5:boxborderw=10",
            "-codec:a", "copy",
            str(output_path)
        ]
        
        try:
            subprocess.run(cmd, check=True, capture_output=True)
            return str(output_path)
        except subprocess.CalledProcessError as e:
            raise Exception(f"Text overlay error: {e.stderr.decode()}")

# ==================== PIPELINE DE GÉNÉRATION ====================

class ContentPipeline:
    """Pipeline complet de génération de contenu (version gratuite)"""
    
    def __init__(self):
        self.script_gen = FreeScriptGenerator()
        self.voice_gen = FreeVoiceGenerator()
        self.image_provider = FreeImageProvider()
        self.video_assembler = FreeVideoAssembler()
    
    async def generate_video(
        self,
        topic: str,
        niche: str,
        duration: int = 30
    ) -> dict:
        """Génère une vidéo complète"""
        
        video_id = str(uuid.uuid4())[:8]
        
        try:
            # 1. Générer le script
            print(f"[{video_id}] Génération du script...")
            script_data = self.script_gen.generate_script(topic, niche, duration)
            
            full_script = f"{script_data['hook']} {script_data['content']} {script_data['cta']}"
            
            # 2. Générer la voix-off
            print(f"[{video_id}] Génération de la voix-off...")
            audio_path = TEMP_DIR / f"{video_id}_audio.mp3"
            await self.voice_gen.generate_voiceover(
                text=full_script,
                output_path=str(audio_path),
                voice="female_claire",
                rate="+15%"  # Plus rapide pour TikTok
            )
            
            # 3. Récupérer les images
            print(f"[{video_id}] Récupération des images...")
            images_data = []
            for suggestion in script_data['visual_suggestions'][:3]:
                imgs = self.image_provider.search_images(suggestion, count=2)
                images_data.extend(imgs[:2])
            
            # Télécharger les images
            image_paths = []
            for i, img_data in enumerate(images_data[:5]):
                img_path = TEMP_DIR / f"{video_id}_img_{i}.jpg"
                self.image_provider.download_image(img_data["url"], str(img_path))
                image_paths.append(str(img_path))
            
            # 4. Assembler la vidéo
            print(f"[{video_id}] Assemblage de la vidéo...")
            video_path = VIDEOS_DIR / f"{video_id}.mp4"
            self.video_assembler.create_slideshow_video(
                images=image_paths,
                audio_path=str(audio_path),
                output_path=str(video_path),
                duration_per_image=duration / len(image_paths)
            )
            
            # 5. Ajouter le hook en overlay
            video_with_text = VIDEOS_DIR / f"{video_id}_final.mp4"
            self.video_assembler.add_text_overlay(
                video_path=str(video_path),
                text=script_data['hook'],
                output_path=str(video_with_text),
                position="top"
            )
            
            # 6. Sauvegarder en BDD
            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO videos (id, title, script, status, video_path, hashtags, description)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                video_id,
                topic,
                full_script,
                "pending_review",
                str(video_with_text),
                " ".join(script_data['suggested_hashtags']),
                script_data['hook']
            ))
            conn.commit()
            conn.close()
            
            print(f"[{video_id}] ✅ Vidéo générée avec succès!")
            
            return {
                "id": video_id,
                "status": "success",
                "script": script_data,
                "video_path": str(video_with_text)
            }
            
        except Exception as e:
            print(f"[{video_id}] ❌ Erreur: {e}")
            return {
                "id": video_id,
                "status": "error",
                "error": str(e)
            }

# ==================== API ENDPOINTS ====================

pipeline = ContentPipeline()

@app.route('/')
def index():
    """Page d'accueil simple"""
    return render_template_string("""
    <!DOCTYPE html>
    <html>
    <head>
        <title>TikTok Automation - Version Gratuite</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                max-width: 800px;
                margin: 50px auto;
                padding: 20px;
                background: #f5f5f5;
            }
            .container {
                background: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            h1 { color: #333; }
            .form-group {
                margin-bottom: 20px;
            }
            label {
                display: block;
                margin-bottom: 5px;
                font-weight: bold;
            }
            input, select {
                width: 100%;
                padding: 10px;
                border: 1px solid #ddd;
                border-radius: 5px;
                font-size: 14px;
            }
            button {
                background: #FF0050;
                color: white;
                border: none;
                padding: 12px 30px;
                border-radius: 5px;
                cursor: pointer;
                font-size: 16px;
            }
            button:hover {
                background: #CC0040;
            }
            .status {
                margin-top: 20px;
                padding: 15px;
                border-radius: 5px;
                display: none;
            }
            .success { background: #d4edda; color: #155724; }
            .error { background: #f8d7da; color: #721c24; }
            .loading { background: #fff3cd; color: #856404; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🎬 TikTok Automation - Gratuit</h1>
            <p>Générez du contenu TikTok automatiquement avec des outils 100% gratuits!</p>
            
            <form id="generateForm">
                <div class="form-group">
                    <label>Sujet de la vidéo:</label>
                    <input type="text" id="topic" placeholder="Ex: 5 astuces de productivité" required>
                </div>
                
                <div class="form-group">
                    <label>Niche:</label>
                    <select id="niche">
                        <option value="education">Éducation</option>
                        <option value="entertainment">Divertissement</option>
                        <option value="lifestyle">Lifestyle</option>
                        <option value="business">Business</option>
                        <option value="technology">Technologie</option>
                        <option value="health">Santé</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Durée (secondes):</label>
                    <input type="number" id="duration" value="30" min="15" max="60">
                </div>
                
                <button type="submit">🚀 Générer la vidéo</button>
            </form>
            
            <div id="status" class="status"></div>
        </div>
        
        <script>
            document.getElementById('generateForm').addEventListener('submit', async (e) => {
                e.preventDefault();
                
                const statusDiv = document.getElementById('status');
                statusDiv.className = 'status loading';
                statusDiv.style.display = 'block';
                statusDiv.innerHTML = '⏳ Génération en cours... (2-5 minutes)';
                
                const formData = {
                    topic: document.getElementById('topic').value,
                    niche: document.getElementById('niche').value,
                    duration: parseInt(document.getElementById('duration').value)
                };
                
                try {
                    const response = await fetch('/api/generate', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(formData)
                    });
                    
                    const data = await response.json();
                    
                    if (data.status === 'success') {
                        statusDiv.className = 'status success';
                        statusDiv.innerHTML = `
                            ✅ Vidéo générée avec succès!<br>
                            ID: ${data.id}<br>
                            <a href="/videos/${data.id}" target="_blank">Voir la vidéo</a>
                        `;
                    } else {
                        statusDiv.className = 'status error';
                        statusDiv.innerHTML = `❌ Erreur: ${data.error}`;
                    }
                } catch (error) {
                    statusDiv.className = 'status error';
                    statusDiv.innerHTML = `❌ Erreur: ${error.message}`;
                }
            });
        </script>
    </body>
    </html>
    """)

@app.route('/api/generate', methods=['POST'])
def generate_content():
    """Génère une nouvelle vidéo"""
    data = request.json
    
    topic = data.get('topic', '')
    niche = data.get('niche', 'education')
    duration = data.get('duration', 30)
    
    if not topic:
        return jsonify({"error": "Topic required"}), 400
    
    # Exécuter le pipeline de génération
    result = asyncio.run(pipeline.generate_video(topic, niche, duration))
    
    return jsonify(result)

@app.route('/api/videos', methods=['GET'])
def list_videos():
    """Liste toutes les vidéos"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM videos ORDER BY created_at DESC")
    videos = [dict(row) for row in cursor.fetchall()]
    
    conn.close()
    return jsonify(videos)

@app.route('/api/videos/<video_id>', methods=['GET'])
def get_video(video_id):
    """Récupère une vidéo spécifique"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM videos WHERE id = ?", (video_id,))
    video = cursor.fetchone()
    
    conn.close()
    
    if not video:
        return jsonify({"error": "Video not found"}), 404
    
    return jsonify(dict(video))

@app.route('/videos/<video_id>')
def serve_video(video_id):
    """Sert le fichier vidéo"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute("SELECT video_path FROM videos WHERE id = ?", (video_id,))
    result = cursor.fetchone()
    
    conn.close()
    
    if not result or not result[0]:
        return "Video not found", 404
    
    video_path = Path(result[0])
    if not video_path.exists():
        return "Video file not found", 404
    
    return send_file(video_path, mimetype='video/mp4')

@app.route('/api/videos/<video_id>/approve', methods=['POST'])
def approve_video(video_id):
    """Approuve une vidéo pour publication"""
    data = request.json
    
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute("""
        UPDATE videos 
        SET status = 'approved',
            hashtags = ?,
            description = ?
        WHERE id = ?
    """, (
        data.get('hashtags', ''),
        data.get('description', ''),
        video_id
    ))
    
    conn.commit()
    conn.close()
    
    return jsonify({"success": True, "message": "Video approved"})

@app.route('/health')
def health():
    """Health check"""
    return jsonify({
        "status": "ok",
        "version": "1.0.0-free",
        "services": {
            "script_generation": "Groq (Llama 3)",
            "voice": "Edge TTS",
            "images": "Pexels",
            "video": "FFmpeg"
        }
    })

# ==================== MAIN ====================

if __name__ == '__main__':
    # Initialiser la base de données
    init_db()
    
    print("=" * 50)
    print("🚀 TikTok Automation - Version Gratuite")
    print("=" * 50)
    print("\n📋 Services utilisés (100% gratuit):")
    print("  • Scripts: Groq (Llama 3)")
    print("  • Voix: Edge TTS (Microsoft)")
    print("  • Images: Pexels")
    print("  • Vidéo: FFmpeg")
    print("\n🌐 Serveur démarré sur http://localhost:5000")
    print("=" * 50)
    
    # Lancer le serveur
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=True
    )
